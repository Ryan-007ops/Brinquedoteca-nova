class MemoryDB:
    def _init_(self):
        self.leitores = {}
        self.livros = {}

db = MemoryDB()
