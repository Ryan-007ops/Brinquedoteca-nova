def get_livro(codigo: int):
    livro = buscar_livro(codigo)
    if not livro:
        raise HTTPException(status_code=404, detail="Livro não encontrado.")
    return livro

@router.put("/{codigo}/preco", response_model=LivroOut)
def put_preco_livro(codigo: int, data: AlterarPrecoInput):
    livro = alterar_preco_livro(codigo, data.preco)
    if not livro:
        raise HTTPException(status_code=404, detail="Livro não encontrado.")
    return livro

@router.get("/{codigo}/preco-final")
def get_preco_final(codigo: int):
    livro = buscar_livro(codigo)
    if not livro:
        raise HTTPException(status_code=404, detail="Livro não encontrado.")
    return {"codigo": livro.codigo, "titulo": livro.titulo, "preco_final": livro.preco_final}

# main.py
from fastapi import FastAPI
from api.routes.leitores import router as leitores_router
from api.routes.livros import router as livros_router

app = FastAPI(title="Biblioteca API")

@app.get("/")
def home():
    return {"msg": "Biblioteca API funcionando"}

app.include_router(leitores_router)
app.include_router(livros_router)